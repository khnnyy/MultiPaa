<?php
include_once "db_conn.php";

$response = null;
$error_message = null;

// Check if both patient_id and device_ip are set
if (isset($_GET["patient_id"]) && isset($_GET["device_ip"])) {
    $patient_id = $_GET["patient_id"];
    $device_ip = $_GET["device_ip"];
    $current_datetime = date("Y-m-d H:i:s");

    $curl = curl_init();
    
    // Ensure the URL is properly formatted with http:// prefix if not already included
    $device_url = (strpos($device_ip, 'http://') === 0) ? $device_ip : "http://$device_ip";
    
    curl_setopt($curl, CURLOPT_URL, "$device_url:80/get_data");
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10); // Set a timeout of 10 seconds
    
    $response = curl_exec($curl);

    if (curl_errno($curl)) {
        $error_message = 'Error: ' . curl_error($curl);
        curl_close($curl);
        // Redirect to error page with the cURL error message
        header("Location: error.php?msg=" . urlencode("Failed to connect to device: " . $error_message));
        exit();
    }

    curl_close($curl);
    
    // Check if response is empty
    if (empty($response)) {
        header("Location: error.php?msg=" . urlencode("No data received from device. Please check if the device is online and try again."));
        exit();
    }
    
    $data = json_decode($response, true);
    
    // Check if JSON decoding failed
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        header("Location: error.php?msg=" . urlencode("Invalid data format received from device: " . json_last_error_msg()));
        exit();
    }
    
    // Check if data array is empty
    if (empty($data)) {
        header("Location: error.php?msg=" . urlencode("Device returned empty data. Please check device configuration."));
        exit();
    }

    // Updated variable names to match the JSON keys from handlePostRequest()
    $temperatureLeft = $data['tempLeft'] ?? null;
    $temperatureRight = $data['tempRight'] ?? null;
    $temperatureDiff = $data['tempDiff'] ?? null; // New field
    $gsrLeft = $data['gsrLeft'] ?? null;
    $gsrRight = $data['gsrRight'] ?? null;
    $heartRateLeft = $data['hrLeft'] ?? null;
    $heartRateRight = $data['hrRight'] ?? null;
    $bloodSaturationLeft = $data['spo2Left'] ?? null;
    $bloodSaturationRight = $data['spo2Right'] ?? null;
    $bodyWeight = $data['weight'] ?? null; // Changed from 'bodyWeight' to 'weight'

    // Check if essential data is missing
    $requiredFields = ['tempLeft', 'tempRight', 'gsrLeft', 'gsrRight', 'hrLeft', 'hrRight', 'spo2Left', 'spo2Right'];
    $missingFields = [];
    
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || $data[$field] === null) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        header("Location: error.php?msg=" . urlencode("Missing required data fields: " . implode(", ", $missingFields)));
        exit();
    }

    $sql = "SELECT diagnostic_id FROM feet_diagnostics WHERE diagnostic_id > 0 ORDER BY diagnostic_id DESC limit 1";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        header("Location: error.php?msg=" . urlencode("Database error: " . mysqli_error($conn)));
        exit();
    }

    $last_id_row = mysqli_fetch_assoc($result);
    $diagnostic_id = ($last_id_row['diagnostic_id'] ?? 0) + 1;

    // Update the SQL query to match the new variable names
    $sql = "INSERT INTO `feet_diagnostics`(`diagnostic_id`, `patient_id`, `tempL`, `tempR`, `hrL`, `hrR`, `spo2L`, `spo2R`, `gsrL`, `gsrR`, `bodyweight`, `datetime`)
    VALUES ('$diagnostic_id', '$patient_id', '$temperatureLeft', '$temperatureRight', '$heartRateLeft', '$heartRateRight', '$bloodSaturationLeft', '$bloodSaturationRight', '$gsrLeft', '$gsrRight', '$bodyWeight', '$current_datetime')";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        header("Location: error.php?msg=" . urlencode("Failed to save diagnostic data: " . mysqli_error($conn)));
        exit();
    }

    // Success - redirect to diagnose page
    header("Location: diagnose.php?diagnostic_id=" . $diagnostic_id);
    exit();
    
} else {
    // Redirect to error page if required parameters are missing
    header("Location: error.php?msg=" . urlencode("Missing required parameters: patient ID and device IP"));
    exit();
}
?>