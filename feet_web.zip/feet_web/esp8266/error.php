<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error - Diagnostic System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 40px;
        }
        .error-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        .error-icon {
            color: #dc3545;
            font-size: 4rem;
            margin-bottom: 20px;
        }
        .error-title {
            color: #dc3545;
            margin-bottom: 20px;
        }
        .error-details {
            background-color: #f8f9fa;
            border-left: 4px solid #dc3545;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<?php include "includes/header.php" ?>
    <div class="container">
        <div class="error-container text-center">
            <div class="error-icon">
                <i class="bi bi-exclamation-triangle-fill"></i>
                ❌
            </div>
            <h2 class="error-title">An Error Occurred</h2>
            
            <?php if(isset($_GET['msg'])): ?>
                <div class="error-details text-start">
                    <p class="mb-0"><strong>Error Details:</strong></p>
                    <p class="mb-0"><?php echo htmlspecialchars($_GET['msg']); ?></p>
                </div>
            <?php else: ?>
                <div class="error-details text-start">
                    <p class="mb-0">An unexpected error occurred. Please try again or contact support.</p>
                </div>
            <?php endif; ?>
            
            <div class="mt-4">
                <a href="home.php" class="btn btn-primary me-2">Return to Dashboard</a>
                <a href="view.php" class="btn btn-outline-secondary">Go Back</a>
            </div>
            
            <div class="mt-4 text-muted small">
                <p>If this problem persists, please contact MultiPaa support..</p>
            </div>
        </div>
    </div>
    <?php include "includes/footer.php" ?>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>